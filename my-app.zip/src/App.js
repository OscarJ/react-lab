import React from 'react';
import logo from './logo.svg';
import './App.css';

class App extends React.Component {
  people = [{
    name: 'Oscar',
    lastName: 'Jimenez',
    id: '112570842',
    city: 'Barva'
  },
  {
    name: 'Daniel',
    lastName: 'Hernandez',
    id: '112540211',
    city: 'Guarari'
  }];
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <div className="App">
        <div class="leftMenu">
          <div>
            <div>
              <span className="col-sm-4">
                Nombre
              </span>
              <input className="col-sm-8"></input>
            </div>
          </div>
        </div>
        <div class="mainSection">
          <table className="table">
            <thead>
              <td>Nombre</td>
              <td>Apellido</td>
              <td>Cedula</td>
              <td>Ciudad</td>
            </thead>
            <tbody>
              {this.people.map(x => {
                return (<tr><td>{x.name}</td>
                  <td>{x.lastName}</td>
                  <td>{x.id}</td>
                  <td>{x.city}</td>
                </tr>);
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default App;
